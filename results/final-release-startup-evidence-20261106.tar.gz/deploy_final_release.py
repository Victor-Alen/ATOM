"""Fast-forward the delivery worktree and verify its default startup."""
from pathlib import Path
import json,socket,subprocess,time
import psutil

w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
repo=Path('/workspace/ATOM-csig-final')
release='1825440c8b59a5d568c5d01c16a68fcd5097768c'
def run(args,cwd=repo):
    subprocess.run(args,cwd=cwd,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
run(['git','fetch',str(w/'final-release.bundle'),'HEAD:refs/remotes/delivery/release-20261106'])
run(['git','merge','--ff-only',release])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==release
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
assert psutil.Process(latest['pid']).cwd()=='/workspace/ATOM-csig-triangular-qk'
run(['/opt/venv/bin/python3','/workspace/ATOM-csig-triangular-qk/scripts/stop_server.py'])
deadline=time.monotonic()+60
while True:
    try:
        for port in [8000,18000]:
            with socket.socket() as sock:
                sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
                sock.bind(('0.0.0.0',port))
        break
    except OSError:
        if time.monotonic()>deadline:raise
        time.sleep(1)
run(['bash','scripts/start_server.sh'])
run(['/opt/venv/bin/python3',str(w/'verify_final_release_start.py')])
(w/'FINAL_RELEASE_DEPLOY_DONE').write_text(release+'\n')
