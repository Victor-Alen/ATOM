"""Verify the delivered checkout against the fully measured core and real HTTP."""
from pathlib import Path
import hashlib,json,subprocess,sys,urllib.request
import psutil
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
selected=json.loads((w/'frozen_final_candidate_20261106.json').read_text());full=Path(selected['full'])
repo=Path('/workspace/ATOM-csig-final');latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text());run=Path(latest['run_dir'])
live=json.loads((run/'manifest.json').read_text());measured=json.loads((full/'manifest.json').read_text())
assert live['cwd']==str(repo) and live['optimization_points']==[1,1,1] and not live['overrides']
assert '--method' not in live['command'] and '--num-speculative-tokens' not in live['command']
assert psutil.Process(latest['pid']).cwd()==str(repo) and psutil.Process(latest['pid']).cmdline()==live['command']
expected_env={key:value.replace(selected['repo'],str(repo)) for key,value in measured['env'].items()}
assert live['env']==expected_env,'Runtime environment differs from measured core'
assert live['command']==measured['command'],'Server command differs from measured core'
snapshot=json.loads((full/'source_hashes.json').read_text());checked=[]
for name,digest in snapshot.items():
    if name.startswith('atom/'):
        assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
        checked.append(name)
smoke=json.loads((run/'smoke.json').read_text());old_smoke=json.loads((full/'smoke.json').read_text())
assert smoke['response']['token_ids']==old_smoke['response']['token_ids']
payload=dict(smoke['request'],stream=True)
request=urllib.request.Request(latest['url']+'/v1/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
chunks=[];done=False
with urllib.request.urlopen(request,timeout=180) as response:
    for raw in response:
        line=raw.decode().strip()
        if line=='data: [DONE]':done=True;break
        if line.startswith('data: '):chunks.append(json.loads(line[6:]))
text=''.join(choice.get('text','') for chunk in chunks for choice in chunk.get('choices',[]))
assert done and text==smoke['response']['choices'][0]['text']
out=w/'final_release_startup_20261106';out.mkdir(exist_ok=False)
with (out/'screen.log').open('w') as log:
    subprocess.run([sys.executable,str(repo/'scripts/validate_public.py'),'--screen','--out',str(out/'correctness')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
with (out/'additional_long_context.log').open('w') as log:
    subprocess.run([sys.executable,str(repo/'scripts/validate_additional_long_context.py'),'--references',str(repo/'validation/additional-long-context-hf'),'--out',str(out/'additional_long_context')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
owned=[latest['pid']]+[p.pid for p in psutil.Process(latest['pid']).children(recursive=True)]
def drm_records(pid):
    records=[]
    for path in Path('/proc/'+str(pid)+'/fdinfo').glob('*'):
        try:
            fields=dict(line.split(':',1) for line in path.read_text().splitlines() if line.startswith('drm-'))
            if 'drm-pdev' in fields:records.append({key:value.strip() for key,value in fields.items()})
        except OSError:pass
    return records
gpu_map=[dict(pid=pid,drm=drm_records(pid)) for pid in owned]
large_allocations=[row for proc in gpu_map for row in proc['drm'] if int(row.get('drm-memory-vram','0 KiB').split()[0])>1024*1024]
assert large_allocations and {row['drm-pdev'] for row in large_allocations}=={'0000:22:00.0'},large_allocations
(out/'gpu-process-map.json').write_text(json.dumps(gpu_map,indent=2))
others=[]
for proc in psutil.process_iter():
    try:
        cmd=proc.cmdline()
        if 'atom.entrypoints.openai_server' in cmd and '8021' in cmd:
            env=proc.environ();assert env.get('HIP_VISIBLE_DEVICES')=='0'
            others.append(dict(pid=proc.pid,cwd=proc.cwd(),command=cmd,hip_device=env.get('HIP_VISIBLE_DEVICES')))
    except (psutil.NoSuchProcess,psutil.AccessDenied):pass
record=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),measured_core=selected['source_commit'],repo=str(repo),pid=latest['pid'],run_dir=str(run),atom_files_checked=len(checked),all_model_source_bytes_match=True,runtime_environment_matches=True,server_command_matches=True,mtp=False,optimization_points=[1,1,1],smoke_token_ids_match_measured_core=True,stream_done=True,stream_text_matches_nonstream=True,correctness=json.loads((out/'correctness/acceptance.json').read_text()),additional_long_context=json.loads((out/'additional_long_context/summary.json').read_text()),other_services_observed=others,owned_process_ids=owned,gpu_process_map=gpu_map,gpu_mapping_method='/proc/PID/fdinfo DRM PCI and VRAM records. rocm-smi could not resolve current service PIDs; no successful KFD PID mapping is claimed.',scope='Final delivered checkout startup and correctness screening, tied by model hashes and identical runtime settings to the separately completed full benchmark. Another GPU has an independent service; this is not a whole-host-idle measurement.')
(out/'manifest.json').write_bytes((run/'manifest.json').read_bytes());(out/'smoke.json').write_bytes((run/'smoke.json').read_bytes())
(out/'verification.json').write_text(json.dumps(record,indent=2));(w/'final-release-startup.json').write_text(json.dumps(record,indent=2))
(out/'DONE').write_text('Delivered checkout starts and serves real streaming/nonstreaming inference; model bytes and runtime settings match measured core.\n')
print(json.dumps(record,indent=2))
