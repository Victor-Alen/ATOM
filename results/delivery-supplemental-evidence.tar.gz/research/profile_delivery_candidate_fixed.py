"""Capture a diagnostic trace after performance/ablation, then restore default."""
from pathlib import Path
import asyncio,datetime,gzip,hashlib,json,os,signal,subprocess,time,urllib.request
import aiohttp,psutil

r=Path('/workspace/logs/step0_operator_parallel_20261104');work=r/'startup_delivery';repo=Path('/workspace/ATOM-csig-final')
pointer=work/'latest_cumulative_ablation.json'
print('WAIT_CUMULATIVE_ABLATION',flush=True)
while not pointer.exists() or not (Path(json.loads(pointer.read_text())['output'])/'DONE').exists():time.sleep(10)
label='delivery_profile_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=r/label;out.mkdir();(work/'latest_delivery_profile.json').write_text(json.dumps(dict(output=str(out),pid=os.getpid())))
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
manifest=json.loads((Path(latest['run_dir'])/'manifest.json').read_text())
assert manifest['optimization_points']==[1,1,1] and manifest['cwd']==str(repo)
subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/stop_server.py')],check=True)
for _ in range(60):
    if not psutil.pid_exists(latest['pid']):break
    time.sleep(1)
assert not psutil.pid_exists(latest['pid'])
traces=out/'traces';cmd=manifest['command']+['--torch-profiler-dir',str(traces)]
env=os.environ.copy();env.update(manifest['env']);env['ATOM_PROFILER_MORE']='0'
# Preserve the startup manifest's repo plus packaged AITER source path.
assert env['PYTHONPATH'].startswith(str(repo)+':') and '/sources/aiter' in env['PYTHONPATH']
def api(path,payload=None):
    req=urllib.request.Request('http://127.0.0.1:8000'+path,data=None if payload is None else json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=900) as f:return json.load(f)
def body(prompt,tokens):return dict(model='/data/models/Mellum2.1-12B-A2.5B-Thinking',prompt=prompt,max_tokens=tokens,temperature=0.,ignore_eos=True,stream=False)
async def batch(prompts,tokens):
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=900),connector=aiohttp.TCPConnector(force_close=True)) as session:
        async def one(p):
            async with session.post('http://127.0.0.1:8000/v1/completions',json=body(p,tokens)) as response:
                response.raise_for_status();return await response.json()
        return await asyncio.gather(*(one(p) for p in prompts))
with (out/'server.log').open('wb') as logfile:
    proc=subprocess.Popen(cmd,cwd=repo,env=env,stdout=logfile,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(manifest,command=cmd,pid=proc.pid,scope='Diagnostic torch profiler only, excluded from all performance tables')
(out/'runtime.json').write_text(json.dumps(record,indent=2));cases=[]
try:
    for _ in range(450):
        assert proc.poll() is None,'Profile server exited'
        try:api('/v1/models');break
        except Exception:time.sleep(2)
    else:raise TimeoutError('Profile startup')
    short='def add(a, b):\n    return'
    strict=json.loads(Path('/workspace/logs/step0_five_gate_20261104/strict_16k_hf.json').read_text())
    source=[json.loads(x)['prompt'] for x in Path('/data/datasets/scenario_a_prompts.jsonl').read_text().splitlines() if x.strip()]
    for name,prompts,tokens in [('single_decode',[short],64),('long_prefill',[strict['prompt']],8),('A32_prefill',source[:32],8)]:
        # Warm the exact shapes before the diagnostic window.
        asyncio.run(batch(prompts,1));before=set(traces.rglob('*.gz'))
        api('/start_profile',{});time.sleep(1)
        t=time.monotonic();responses=asyncio.run(batch(prompts,tokens));duration=time.monotonic()-t
        api('/stop_profile',{})
        for _ in range(120):
            files=set(traces.rglob('*.gz'))-before
            if files:
                sizes={str(p):p.stat().st_size for p in files};time.sleep(2)
                if sizes=={str(p):p.stat().st_size for p in files}:break
            time.sleep(1)
        assert files,'Trace file absent'
        row=dict(name=name,prompt_tokens=[v['usage']['prompt_tokens'] for v in responses],output_tokens=tokens,requests=len(prompts),diagnostic_wall_s=duration,trace_files=[str(p.relative_to(out)) for p in files])
        cases.append(row);(out/'cases.json').write_text(json.dumps(cases,indent=2));print('PROFILE_CASE',json.dumps(row),flush=True)
finally:
    if proc.poll() is None:
        assert psutil.Process(proc.pid).cmdline()==cmd and psutil.Process(proc.pid).cwd()==str(repo)
        os.killpg(proc.pid,signal.SIGTERM)
        try:proc.wait(timeout=60)
        except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=30)
    with (out/'restore.log').open('w') as log:
        subprocess.run(['bash',str(repo/'scripts/start_server.sh')],stdout=log,stderr=subprocess.STDOUT,check=True)
assert len(cases)==3
digest=[]
for row in cases:
    kernels=[]
    for name in row['trace_files']:
        with gzip.open(out/name,'rt') as f:data=json.load(f)
        kernels.extend(e for e in data['traceEvents'] if e.get('cat')=='kernel' and e.get('ph')=='X')
    groups={};names={}
    for event in kernels:
        name=event['name'];duration=event.get('dur',0)/1000
        category='other'
        low=name.lower()
        if 'moe' in low or 'fused_expert' in low:category='moe'
        elif 'softmax' in low or 'cached_block' in low or '_small_cached_rows' in low or 'streaming' in low:category='softmax'
        elif 'pv_' in low or '_pv' in low:category='sparse_pv'
        elif 'qk_' in low or '_qk' in low:category='sparse_qk'
        elif 'gemm' in low or 'matmul' in low or low.startswith('cijk_'):category='gemm'
        elif 'norm' in low:category='norm'
        groups[category]=groups.get(category,0)+duration;names[name]=names.get(name,0)+duration
    digest.append(dict(row,kernel_events=len(kernels),sum_gpu_kernel_ms=sum(e.get('dur',0) for e in kernels)/1000,groups_ms=groups,top_kernels=sorted(names.items(),key=lambda x:-x[1])[:25]))
(out/'digest.json').write_text(json.dumps(dict(scope='Name-based GPU event categorization; sums may overlap across streams; not request wall latency',cases=digest),indent=2))
(out/'DONE').write_text('Three diagnostic windows captured; default startup restored.\n')
print('DELIVERY_PROFILE_DONE',out,flush=True)
