from pathlib import Path
import json,os,sys,time
work=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery');repo=Path('/workspace/ATOM-csig-final')
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
manifest=json.loads((Path(latest['run_dir'])/'manifest.json').read_text())
os.environ.update(manifest['env']);sys.path[:0]=[str(work),str(repo)]
import torch,triton
from mellum_softmax_lane_cache_candidate import softmax as candidate
from atom.model_ops.mellum_prefill_softmax_gluon import softmax as accepted
torch.manual_seed(20261106);records=[];out=work/'lane_cache_operator_validation.json'
for n in (3073,4095,4096,4097,6143,7169,8192,8193,12001,15965,16384):
    score=torch.randn((1,32,n,n),device='cuda',dtype=torch.bfloat16)*8
    scale=128**-.5;reference=torch.empty_like(score)
    ix=torch.arange(n,device='cuda');allowed=ix[None,:]<=ix[:,None]
    for h in range(0,32,4):
        scaled=(score[:,h:h+4]*scale).masked_fill(~allowed,torch.finfo(torch.bfloat16).min)
        reference[:,h:h+4]=torch.softmax(scaled,dim=-1,dtype=torch.float32).to(torch.bfloat16)
    got=candidate(score,n,n,None,scale);difference=int((got!=reference).sum().item())
    repeats=40 if n in (8193,16384) else 1;repeated_max=difference
    if difference==0:
        for _ in range(repeats-1):repeated_max=max(repeated_max,int((candidate(score,n,n,None,scale)!=reference).sum().item()))
    milliseconds={}
    if repeated_max==0:
        for name,fn in (('accepted',accepted),('candidate',candidate)):
            milliseconds[name]=[triton.testing.do_bench(lambda:fn(score,n,n,None,scale),warmup=20,rep=100) for _ in range(3)]
    row=dict(n=n,difference=difference,repeated_max=repeated_max,repeats=repeats,milliseconds=milliseconds)
    records.append(row);out.write_text(json.dumps(dict(scope='Fixed-input full causal attention softmax only; no model acceptance',complete=False,results=records),indent=2));print(json.dumps(row),flush=True)
    del score,reference,got,scaled,allowed,ix;torch.cuda.empty_cache()
out.write_text(json.dumps(dict(scope='Fixed-input full causal attention softmax only; no model acceptance',complete=True,results=records),indent=2))
