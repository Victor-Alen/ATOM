from pathlib import Path
import datetime,json,os,subprocess,sys,time
import psutil
r=Path('/workspace/logs/step0_operator_parallel_20261104');work=r/'startup_delivery';repo=Path('/workspace/ATOM-csig-final')
pointer=work/'latest_delivery_profile.json'
print('WAIT_DELIVERY_PROFILE',flush=True)
while not pointer.exists() or not (Path(json.loads(pointer.read_text())['output'])/'DONE').exists():time.sleep(10)
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
manifest=json.loads((Path(latest['run_dir'])/'manifest.json').read_text());assert manifest['cwd']==str(repo)
subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/stop_server.py')],check=True)
for _ in range(60):
    if not psutil.pid_exists(latest['pid']):break
    time.sleep(1)
assert not psutil.pid_exists(latest['pid'])
os.environ.update(manifest['env']);sys.path[:0]=[str(work),str(repo)]
import torch,triton
from mellum_prefill_softmax_global_cache import softmax as candidate
from atom.model_ops.mellum_prefill_softmax_gluon import softmax as accepted
torch.manual_seed(20261106);records=[];out=work/'global_softmax_operator_validation.json'
try:
    for n in (4095,4096,4097,6143,7169,8192,8193,12001,15965,16384):
        score=torch.randn((1,32,n,n),device='cuda',dtype=torch.bfloat16)*8
        scale=128**-.5
        reference=torch.empty_like(score)
        indices=torch.arange(n,device='cuda');allowed=indices[None,:]<=indices[:,None]
        for h in range(0,32,4):
            scaled=score[:,h:h+4]*scale
            scaled=scaled.masked_fill(~allowed,torch.finfo(torch.bfloat16).min)
            reference[:,h:h+4]=torch.softmax(scaled,dim=-1,dtype=torch.float32).to(torch.bfloat16)
        got=candidate(score,n,n,None,scale,rows=1)
        difference=int((got!=reference).sum().item())
        prior=accepted(score,n,n,None,scale)
        prior_difference=int((prior!=reference).sum().item())
        del prior
        repeats=40 if n in (8193,16384) else 1
        repeated_max=difference
        if difference==0:
            for _ in range(repeats-1):repeated_max=max(repeated_max,int((candidate(score,n,n,None,scale,rows=1)!=reference).sum().item()))
        milliseconds={}
        if difference==0:
            milliseconds['accepted']=triton.testing.do_bench(lambda:accepted(score,n,n,None,scale),warmup=5,rep=25)
            milliseconds['candidate']=triton.testing.do_bench(lambda:candidate(score,n,n,None,scale,rows=1),warmup=5,rep=25)
        row=dict(n=n,shape=list(score.shape),difference=difference,accepted_difference=prior_difference,repeats=repeats,repeated_max=repeated_max,milliseconds=milliseconds)
        records.append(row);out.write_text(json.dumps(dict(scope='Isolated full-attention softmax fixed-input validation and microbenchmark; no model acceptance',results=records,complete=False),indent=2));print('GLOBAL_SOFTMAX',json.dumps(row),flush=True)
        del score,reference,got,scaled,allowed,indices;torch.cuda.empty_cache()
    out.write_text(json.dumps(dict(scope='Isolated full-attention softmax fixed-input validation and microbenchmark; no model acceptance',results=records,complete=True,passed=all(x['repeated_max']==0 and x['accepted_difference']==0 for x in records)),indent=2))
finally:
    # Drop allocations and context before restoring the production process.
    print('PROBE_FINISHED; restore is handled by parent shell after process exit',flush=True)
