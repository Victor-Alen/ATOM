from pathlib import Path
import gc,json,os,sys,time
work=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery');repo=Path('/workspace/ATOM-csig-final')
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
manifest=json.loads((Path(latest['run_dir'])/'manifest.json').read_text());os.environ.update(manifest['env']);sys.path[:0]=[str(work),str(repo)]
import torch,triton
from mellum_prefill_sparse_pv_tiling import pv
torch.set_num_threads(2);torch.manual_seed(20261106);results=[];started=time.time()
def save(done=False):
    (work/'pv_tiling_operator_validation.json').write_text(json.dumps(dict(scope='Fixed-input SWA PV tile screening; no model acceptance',complete=done,cases=results,seconds=time.time()-started),indent=2))
with torch.inference_mode():
    for n in (3073,4095,4096,4097,7169,8193,12580,15965,16384):
        p=torch.zeros((1,32,n,n),device='cuda',dtype=torch.bfloat16)
        for start in range(0,n,128):
            stop=min(n,start+128);left=max(0,start-1023)
            rr=torch.arange(start,stop,device='cuda')[:,None];kk=torch.arange(left,stop,device='cuda')[None,:]
            values=torch.randn((1,32,stop-start,stop-left),device='cuda',dtype=torch.float32)*3
            values.masked_fill_(~((kk<=rr)&(kk>rr-1024)),float('-inf'))
            p[:,:,start:stop,left:stop]=values.softmax(-1).to(torch.bfloat16)
        v=torch.randn((1,32,n,128),device='cuda',dtype=torch.bfloat16);ref=p@v
        variants=[]
        for bm in (32,64,128,256):
            try:
                got=pv(p,v,bm=bm);different=int((got!=ref).sum().item());repeats=[]
                if not different and n in (4095,16384):repeats=[int((pv(p,v,bm=bm)!=ref).sum().item()) for _ in range(40)]
                timing=triton.testing.do_bench(lambda:pv(p,v,bm=bm),warmup=20,rep=100) if different==0 else None
                row=dict(bm=bm,different=different,repeats=repeats,milliseconds=timing)
            except Exception as error:
                row=dict(bm=bm,error=repr(error))
            variants.append(row);print('PV_TILE',n,json.dumps(row),flush=True)
        results.append(dict(n=n,variants=variants));save()
        del p,v,ref,values;gc.collect();torch.cuda.empty_cache()
save(True);print('PV_TILING_OPERATOR_DONE',flush=True)
