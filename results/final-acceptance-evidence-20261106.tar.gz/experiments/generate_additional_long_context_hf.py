"""Fresh BF16 HF eager references for three nontrivial, exactly-16K inputs."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
import torch
repo=Path('/workspace/ATOM-csig-global-qk');w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
out=w/'additional_long_context_hf_20261106';out.mkdir(exist_ok=False)
sys.path.insert(0,str(repo/'scripts'))
from hf_reference_generate import MODEL_PATH,load_mellum_classes,load_checkpoint_experts
from transformers import AutoTokenizer
torch.set_num_threads(8)
Config,LM=load_mellum_classes();mod=sys.modules['transformers.models.mellum.modeling_mellum']
cfg=Config.from_pretrained(MODEL_PATH);base=mod.MellumPreTrainedModel;original=base._init_weights;skipped=[]
def init(self,module):
    if isinstance(module,mod.MellumExperts):skipped.append(1);return
    return original(self,module)
base._init_weights=init
try:model,info=LM.from_pretrained(MODEL_PATH,config=cfg,dtype=torch.bfloat16,attn_implementation='eager',output_loading_info=True)
finally:base._init_weights=original
expected={f'model.layers.{i}.mlp.experts.{n}' for i in range(28) for n in ['gate_up_proj','down_proj']}
assert set(info['missing_keys'])==expected and not info['mismatched_keys'] and len(skipped)==28
load_checkpoint_experts(model,MODEL_PATH);model=model.cuda().eval();tokenizer=AutoTokenizer.from_pretrained(MODEL_PATH)
def generate(prompt):
    ids=tokenizer.encode(prompt,add_special_tokens=False);inputs=torch.tensor([ids],device='cuda')
    with torch.inference_mode():
        output=model.generate(input_ids=inputs,attention_mask=torch.ones_like(inputs),max_new_tokens=64,do_sample=False,use_cache=True,eos_token_id=None,pad_token_id=0)
    tokens=output[0,len(ids):].tolist();assert len(tokens)==64
    return ids,tokens
old=[json.loads(s) for s in Path('/workspace/correctness/hf_scenario_c_200_eager.jsonl').read_text().splitlines()]
strict=json.loads(Path('/workspace/logs/step0_five_gate_20261104/strict_16k_hf.json').read_text())
anchors=[]
for name,record in [('C0000',old[0]),('strict16k',strict)]:
    ids,tokens=generate(record['prompt']);same=tokens==record['token_ids'][:64]
    anchors.append(dict(name=name,input_tokens=len(ids),exact_historical=same,token_ids=tokens))
(out/'anchors.json').write_text(json.dumps(anchors,indent=2));assert all(row['exact_historical'] for row in anchors),'Fresh HF anchors differ from historical reference'
dataset=Path('/data/datasets/scenario_c_prompts.jsonl');source=[json.loads(line) for line in dataset.read_text().splitlines() if line.strip()]
rows=[]
for index in (0,49,199):
    original_prompt=source[index]['prompt'];text=original_prompt
    while len(tokenizer.encode(text,add_special_tokens=False))<16384:text+='\n'+original_prompt
    ids=tokenizer.encode(text,add_special_tokens=False)[:16384]
    prompt=tokenizer.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)
    assert tokenizer.encode(prompt,add_special_tokens=False)==ids and len(ids)==16384
    started=time.monotonic();actual,tokens=generate(prompt);assert actual==ids
    row=dict(id='LONG16K-'+source[index]['id'],source_id=source[index]['id'],prompt=prompt,prompt_token_ids=ids,prompt_tokens=16384,token_ids=tokens,attention='eager',dtype='bfloat16',elapsed_s=time.monotonic()-started)
    rows.append(row);print(row['id'],'generated',flush=True)
with (out/'references.jsonl').open('w') as file:
    for row in rows:file.write(json.dumps(row,ensure_ascii=False)+'\n')
_,again=generate(rows[0]['prompt']);repeat_exact=again==rows[0]['token_ids']
assert repeat_exact,'Fresh HF same-process repeat differs'
manifest=dict(scope='Additional correctness only; public C prompts repeated then token-prefix truncated to exactly 16384. Performance datasets unchanged.',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),torch=torch.__version__,transformers=__import__('transformers').__version__,architecture=torch.cuda.get_device_properties(0).gcnArchName,env={k:os.environ.get(k) for k in ('ROCR_VISIBLE_DEVICES','HIP_VISIBLE_DEVICES')},dataset_sha256=hashlib.file_digest(dataset.open('rb'),'sha256').hexdigest(),reference_sha256=hashlib.file_digest((out/'references.jsonl').open('rb'),'sha256').hexdigest(),anchors=anchors,first_case_repeat_exact=repeat_exact,generation=dict(attention='eager',dtype='bfloat16',max_new_tokens=64,do_sample=False,use_cache=True,eos_token_id=None,pad_token_id=0),source_hashes={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'reference/hf_mellum').glob('*.py')})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2));(out/'DONE').write_text('Three new 16K references; two historical anchors and one same-process repeat checked.\n');print('LONG_CONTEXT_HF_DONE',flush=True)
