"""Sweep CTA warp count while preserving all 512 logical lanes and FP32 additions."""
from pathlib import Path
import gc,importlib.util,json,statistics,sys
import torch
from atom.model_ops.mellum_prefill_softmax_hybrid import softmax as reference_softmax
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
source=Path('/workspace/ATOM-csig-global-qk/atom/model_ops/mellum_prefill_softmax_lane_cache.py').read_text()
modules={}
for warps in (2,4,8):
    modified=source.replace('[1,8]',f'[1,{warps}]').replace('[1,8,1]',f'[1,{warps},1]').replace('num_warps=8',f'num_warps={warps}')
    modified=modified.replace('    _lane_cache[','    compiled=_lane_cache[').replace('    return out\n','    return out,compiled\n')
    path=w/f'lane_occupancy_w{warps}.py';path.write_text(modified)
    spec=importlib.util.spec_from_file_location(f'lane_occupancy_w{warps}',path);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);modules[warps]=module
torch.manual_seed(20261106);results=[]
def measure(fn):
    for _ in range(3):y=fn()
    torch.cuda.synchronize();times=[]
    for _ in range(7):
        a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
        a.record();y=fn();b.record();b.synchronize();times.append(a.elapsed_time(b))
    return statistics.median(times)
for n in (4097,6143,7169,8192,8193,12001,15965,16384):
    s=torch.randn((1,32,n,n),device='cuda',dtype=torch.bfloat16)*8
    def reference():return reference_softmax(s,n,n,None,128**-.5)
    ref=reference();row=dict(n=n,reference_ms=measure(reference),candidates=[])
    for warps,module in modules.items():
        entry=dict(warps=warps)
        try:
            got,compiled=module.softmax(s,n,n,None,128**-.5);torch.cuda.synchronize()
            entry['different']=int((got!=ref).sum().item())
            for key in ('n_regs','n_spills'):
                value=getattr(compiled,key,None)
                if isinstance(value,(int,float)):entry[key]=value
            entry['metadata']=str(getattr(compiled,'metadata',None))
            if entry['different']==0:
                entry['ms']=measure(lambda:module.softmax(s,n,n,None,128**-.5)[0])
                if n in (8193,16384) and warps!=8:
                    entry['repeat40_different']=[int((module.softmax(s,n,n,None,128**-.5)[0]!=ref).sum().item()) for _ in range(40)]
            del got
        except Exception as error:entry['error']=repr(error)
        row['candidates'].append(entry);print(json.dumps(dict(n=n,**entry)),flush=True)
    results.append(row)
    (w/'lane_occupancy_operator_validation.json').write_text(json.dumps(dict(scope='FIXED_INPUT_OPERATOR_ONLY; 512 logical reduction lanes unchanged',results=results),indent=2))
    del s,ref;gc.collect();torch.cuda.empty_cache()
print('LANE_OCCUPANCY_PROBE_DONE',flush=True)
