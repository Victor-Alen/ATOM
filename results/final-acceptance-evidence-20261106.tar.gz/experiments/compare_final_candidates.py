"""Read complete result records; no GPU operations and no automatic promotion."""
from pathlib import Path
import json
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
rows=[]
for label,repo,pointer in [('global_qk','/workspace/ATOM-csig-global-qk','latest_global_qk_model.json'),('triangular_qk','/workspace/ATOM-csig-triangular-qk','latest_triangular_qk_model.json')]:
    folder=Path(json.loads((w/pointer).read_text())['output'])
    assert (folder/'DONE').exists(),(label,'not complete')
    summary=json.loads((folder/'performance/audited_summary.json').read_text())
    correct=json.loads((folder/'correctness/acceptance.json').read_text())
    assert summary['repeats']==3 and summary['all_requests_successful'] and summary['all_outputs_256'] and summary['all_requests_streamed'] and correct['passed']
    rows.append(dict(label=label,repo=repo,full=str(folder),source_commit=(folder/'source_commit.txt').read_text().strip(),metrics=summary['metrics'],correctness=correct))
base,candidate=rows
keys=['A_output_tokens_per_s_gpu','B_TPOT_p50_ms','C_TPOT_p99_ms','C_TTFT_p99_ms']
relative={key:(candidate['metrics'][key]['median']/base['metrics'][key]['median']-1)*100 for key in keys}
no_regression=(relative[keys[0]]>=-1 and all(relative[key]<=1 for key in keys[1:3]))
preferred=candidate if no_regression and relative[keys[3]]<0 else base
record=dict(scope='Complete three-round, same-protocol warm-process comparisons. Medians are observations, not statistical significance claims.',criteria='Correctness + full request audit required; prioritize lower C TTFT median; reject >1% regression in A/B/C TPOT. Root must deliberately freeze selection.',candidates=rows,candidate_relative_percent=relative,passes_no_regression_guard=no_regression,recommended=preferred['label'],recommended_selection={key:preferred[key] for key in ('repo','full','source_commit')})
(w/'final_candidate_comparison.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
