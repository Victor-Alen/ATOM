from pathlib import Path
import gc,json,statistics
import torch
from atom.model_ops.mellum_prefill_global_qk import try_qk as original
import triangular_global_qk_candidate as candidate
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
torch.manual_seed(20261106);results=[]
def measure(fn):
    for _ in range(3):y=fn()
    torch.cuda.synchronize();times=[]
    for _ in range(7):
        a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
        a.record();y=fn();b.record();b.synchronize();times.append(a.elapsed_time(b))
    return statistics.median(times)
def differences(a,b,n):
    count=0;cols=torch.arange(n,device='cuda')[None,:]
    for start in range(0,n,256):
        stop=min(n,start+256);mask=cols<=torch.arange(start,stop,device='cuda')[:,None]
        count+=int(((a[0,:,start:stop]!=b[0,:,start:stop])&mask).sum().item())
    return count
for n in (2048,2049,4095,4096,12289,13001,14336,15360,15965,16384):
    q=torch.randn((n,32,128),device='cuda',dtype=torch.bfloat16)
    k=torch.randn((n,4,128),device='cuda',dtype=torch.bfloat16)
    ref=original(q,k)
    if ref is None:
        print('UNSUPPORTED_PROFILE',n,flush=True);del q,k;continue
    row=dict(n=n,original_ms=measure(lambda:original(q,k)))
    try:
        got=candidate.try_qk(q,k);torch.cuda.synchronize();row['different']=differences(got,ref,n)
        if row['different']==0:
            row['candidate_ms']=measure(lambda:candidate.try_qk(q,k))
            if n in (12289,16384):row['repeat40_different']=[differences(candidate.try_qk(q,k),ref,n) for _ in range(40)]
        del got
    except Exception as error:row['error']=repr(error)
    results.append(row);print(json.dumps(row),flush=True)
    (w/'triangular_qk_operator_validation.json').write_text(json.dumps(dict(scope='FIXED_INPUT_OPERATOR_ONLY; compare only written causal positions against the already HF-validated global-QK kernel',results=results),indent=2))
    del q,k,ref;gc.collect();torch.cuda.empty_cache()
print('TRIANGULAR_QK_PROBE_DONE',flush=True)
