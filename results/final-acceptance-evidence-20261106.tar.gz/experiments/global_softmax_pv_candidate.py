"""Full-attention softmax cached in the frozen ATen lane/ILP accumulation order."""
import torch
import triton as tr
from triton.experimental import gluon
from triton.experimental.gluon import language as gl

@gluon.jit
def _scaled(S,base,pos,valid,qpos,shift,SCALE:gl.constexpr):
    ok=valid & (pos+shift<=qpos)
    raw=gl.load(S+base+pos,ok,0).to(gl.float32)
    return gl.where(ok,(raw*SCALE).to(gl.bfloat16).to(gl.float32),float('-inf'))

@gluon.jit
def _exp(x):
    y=gl.exp(x)
    return gl.where(y<1.1754943508222875e-38,0.0,y)

@gluon.jit
def _row(values,b:gl.constexpr,B:gl.constexpr):
    idx=gl.full((1,512),b,gl.int32,gl.BlockedLayout([1,1],[1,64],[1,8],[1,0]))
    return gl.sum(gl.gather(values,idx,axis=0),axis=0)

@gluon.jit
def _row_stats(S,STATS,N,Q,CTX,SCALE:gl.constexpr,B:gl.constexpr,ALIGNED:gl.constexpr):
    row=gl.program_id(0);base=row.to(gl.int64)*N
    qpos=row%Q+CTX-Q;key_shift=CTX-N
    layout:gl.constexpr=gl.BlockedLayout([1,1],[1,64],[1,8],[1,0])
    lanes=gl.arange(0,512,layout=gl.SliceLayout(0,layout))
    blocks=gl.arange(0,B,layout=gl.SliceLayout(1,layout))
    if ALIGNED:
        start=0;bulk=gl.cdiv(N,2048)*2048
    else:
        shift=((row%4)*(N%4))%4
        start=gl.where(shift>0,512-shift,0)
        bulk=((N-start)//2048)*2048
    pos=start+blocks[:,None]*2048+lanes[None,:]*4
    ok=blocks[:,None]*2048<bulk
    x0=_scaled(S,base,pos+0,ok&(pos+0<N),qpos,key_shift,SCALE)
    x1=_scaled(S,base,pos+1,ok&(pos+1<N),qpos,key_shift,SCALE)
    x2=_scaled(S,base,pos+2,ok&(pos+2<N),qpos,key_shift,SCALE)
    x3=_scaled(S,base,pos+3,ok&(pos+3<N),qpos,key_shift,SCALE)
    m=gl.maximum(gl.maximum(gl.max(x0,0),gl.max(x1,0)),gl.maximum(gl.max(x2,0),gl.max(x3,0)))
    if not ALIGNED:
        prefix=lanes-shift
        xp=_scaled(S,base,prefix,(shift>0)&(prefix>=0)&(prefix<N),qpos,key_shift,SCALE)
        tail=start+bulk+lanes
        xt0=_scaled(S,base,tail,tail<N,qpos,key_shift,SCALE)
        xt1=_scaled(S,base,tail+512,tail+512<N,qpos,key_shift,SCALE)
        xt2=_scaled(S,base,tail+1024,tail+1024<N,qpos,key_shift,SCALE)
        xt3=_scaled(S,base,tail+1536,tail+1536<N,qpos,key_shift,SCALE)
        m=gl.maximum(m,gl.maximum(xp,gl.maximum(gl.maximum(xt0,xt1),gl.maximum(xt2,xt3))))
    mx=gl.max(m,0)
    e0=_exp(x0-mx);e1=_exp(x1-mx);e2=_exp(x2-mx);e3=_exp(x3-mx)
    if ALIGNED:
        acc=gl.full((512,),0.0,gl.float32,gl.SliceLayout(0,layout))
    else:
        ep=_exp(xp-mx);et0=_exp(xt0-mx);et1=_exp(xt1-mx);et2=_exp(xt2-mx);et3=_exp(xt3-mx)
        acc=ep
    for block in gl.static_range(B):
        acc=acc+_row(e0,block,B)
        acc=acc+_row(e1,block,B)
        acc=acc+_row(e2,block,B)
        acc=acc+_row(e3,block,B)
    if not ALIGNED:
        acc=acc+et0;acc=acc+et1;acc=acc+et2;acc=acc+et3
    for step in gl.static_range(6):
        src=lanes//64*64+gl.minimum(lanes%64+(32>>step),63)
        acc=acc+gl.gather(acc,src,axis=0)
    warp=gl.gather(acc,gl.minimum(lanes,7)*64,axis=0)
    warp=gl.where(lanes<8,warp,0.0)
    for step in gl.static_range(6):
        warp=warp+gl.gather(warp,gl.minimum(lanes+(32>>step),63),axis=0)
    den=gl.sum(gl.where(lanes==0,warp,0.0),0)
    inv=gl.div_rn(1.0,den)
    gl.store(STATS+row,mx)
    gl.store(STATS+32*N+row,inv)

@gluon.jit
def _prob(S,offset,mask,mx,inv,SCALE:gl.constexpr):
    raw=gl.load(S+offset,mask,0).to(gl.float32)
    scaled=(raw*SCALE).to(gl.bfloat16).to(gl.float32)
    value=_exp(scaled-mx)*inv
    return gl.where(mask,value,0.0).to(gl.bfloat16)

@gluon.jit
def _fused_pv(S,V,STATS,O,N,SCALE:gl.constexpr,MI:gl.constexpr,KW:gl.constexpr,ROW_TILE:gl.constexpr,DEPTH:gl.constexpr,ROTATE:gl.constexpr,BM:gl.constexpr,BN:gl.constexpr):
    qb=gl.program_id(0);head=gl.program_id(1);qbase=qb*BM
    pl:gl.constexpr=gl.BlockedLayout([1,8],[4,16],[4,1],[1,0])
    vl:gl.constexpr=gl.BlockedLayout([1,8],[4,16],[4,1],[1,0])
    rows=qbase+gl.arange(0,BM,layout=gl.SliceLayout(1,pl))
    mx=gl.load(STATS+head*N+rows,rows<N,0)[:,None]
    inv=gl.load(STATS+32*N+head*N+rows,rows<N,0)[:,None]
    pk=gl.arange(0,DEPTH,layout=gl.SliceLayout(0,pl))
    vk=gl.arange(0,DEPTH,layout=gl.SliceLayout(1,vl))
    cols=gl.arange(0,BN,layout=gl.SliceLayout(0,vl))
    mfma:gl.constexpr=gl.amd.AMDMFMALayout(version=3,instr_shape=[MI,MI,16 if MI==16 else 8],transposed=True,warps_per_cta=[1,4])
    lhs:gl.constexpr=gl.DotOperandLayout(0,mfma,k_width=KW)
    rhs:gl.constexpr=gl.DotOperandLayout(1,mfma,k_width=KW)
    acc=gl.zeros((BM,BN),gl.float32,mfma)
    first=0
    last=gl.minimum(N//DEPTH,(qbase+BM+DEPTH-1)//DEPTH)
    blocks=last-first
    if ROTATE:
        rotation=(qbase//ROW_TILE)%(N//DEPTH)
        begin=gl.where((rotation>=first)&(rotation<last),rotation,first)
    else:
        begin=first
    for i in range(blocks):
        block=first+(begin-first+i)%blocks
        kk=block*DEPTH
        p=_prob(S,(head.to(gl.int64)*N+rows[:,None])*N+kk+pk[None,:],(rows[:,None]<N)&(kk+pk[None,:]<=rows[:,None]),mx,inv,SCALE)
        v=gl.load(V+(head.to(gl.int64)*N+kk+vk[:,None])*128+cols[None,:])
        acc=gl.amd.cdna3.mfma(gl.convert_layout(p,lhs),gl.convert_layout(v,rhs),acc)
    if N%DEPTH!=0 and qbase+BM>N//DEPTH*DEPTH:
        kk=N//DEPTH*DEPTH
        p=_prob(S,(head.to(gl.int64)*N+rows[:,None])*N+kk+pk[None,:],(rows[:,None]<N)&(kk+pk[None,:]<N)&(kk+pk[None,:]<=rows[:,None]),mx,inv,SCALE)
        v=gl.load(V+(head.to(gl.int64)*N+kk+vk[:,None])*128+cols[None,:],kk+vk[:,None]<N,0)
        tail_lhs:gl.constexpr=gl.DotOperandLayout(0,mfma,k_width=4)
        tail_rhs:gl.constexpr=gl.DotOperandLayout(1,mfma,k_width=4)
        acc=gl.amd.cdna3.mfma(gl.convert_layout(p,tail_lhs),gl.convert_layout(v,tail_rhs),acc)
    ol:gl.constexpr=gl.BlockedLayout([1,4],[4,16],[4,1],[1,0])
    result=gl.convert_layout(acc,ol)
    rr=qbase+gl.arange(0,BM,layout=gl.SliceLayout(1,ol))
    cc=gl.arange(0,BN,layout=gl.SliceLayout(0,ol))
    gl.store(O+(head*N+rr[:,None])*128+cc[None,:],result.to(gl.bfloat16),rr[:,None]<N)

def attention(scores,value,scale,mi=16,kw=8,row_tile=288,depth=64,rotate=False,bm=32):
    n=scores.shape[-1]
    assert scores.shape==(1,32,n,n) and scores.is_contiguous() and scores.dtype==torch.bfloat16
    assert value.shape==(1,32,n,128) and value.is_contiguous() and value.dtype==torch.bfloat16
    stats=torch.empty((2,32*n),device=scores.device,dtype=torch.float32)
    _row_stats[(32*n,)](scores,stats,n,n,n,scale,tr.next_power_of_2(tr.cdiv(n,2048)),n%4==0,num_warps=8,enable_fp_fusion=False)
    out=torch.empty_like(value)
    assert not rotate or row_tile % bm == 0
    _fused_pv[(tr.cdiv(n,bm),32)](scores,value,stats,out,n,scale,mi,kw,row_tile,depth,rotate,bm,128,num_warps=4,enable_fp_fusion=False)
    return out
