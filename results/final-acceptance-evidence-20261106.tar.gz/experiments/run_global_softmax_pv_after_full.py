"""Run one isolated operator only after the committed model's full test finishes."""
from pathlib import Path
import json,os,subprocess,time
import psutil
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
pointer=w/'latest_global_qk_model.json'
while not pointer.exists():time.sleep(10)
full=json.loads(pointer.read_text());folder=Path(full['output'])
while not (folder/'DONE').exists():
    if json.loads(pointer.read_text())['stage']=='failed':
        raise RuntimeError('Global-QK model failed; leave restored control untouched for review')
    if not psutil.pid_exists(full['pid']):raise RuntimeError('Model driver ended without DONE')
    time.sleep(10)
audited=json.loads((folder/'performance/audited_summary.json').read_text())
assert audited['all_requests_successful'] and audited['repeats']==3
repo=Path('/workspace/ATOM-csig-global-qk')
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
manifest=json.loads((Path(latest['run_dir'])/'manifest.json').read_text())
assert manifest['cwd']==str(repo)
assert psutil.Process(latest['pid']).cmdline()==manifest['command']
subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/stop_server.py')],check=True)
for _ in range(60):
    if not psutil.pid_exists(latest['pid']):break
    time.sleep(1)
assert not psutil.pid_exists(latest['pid'])
env=os.environ.copy();env.update(manifest['env']);code=-1
try:
    with (w/'global_softmax_pv_probe.log').open('w') as log:
        code=subprocess.run(['/opt/venv/bin/python3',str(w/'probe_global_softmax_pv.py')],env=env,cwd=w,stdout=log,stderr=subprocess.STDOUT).returncode
finally:
    with (w/'global_softmax_pv_restore.log').open('w') as log:
        subprocess.run(['bash',str(repo/'scripts/start_server.sh')],stdout=log,stderr=subprocess.STDOUT,check=True)
(w/'GLOBAL_SOFTMAX_PV_RESTORED').write_text(str(code))
print('GLOBAL_SOFTMAX_PV_DONE',code,flush=True)
