"""Prepare a separate two-stage exact-order softmax/PV fusion experiment."""
from pathlib import Path
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
repo=Path('/workspace/ATOM-csig-global-qk')
stats=(repo/'atom/model_ops/mellum_prefill_softmax_lane_cache.py').read_text()
stats=stats[:stats.index('    if ALIGNED:\n        packed:')]
stats=stats.replace('def _lane_cache(S,P,N,Q,CTX,','def _row_stats(S,STATS,N,Q,CTX,')
stats+='''    gl.store(STATS+row,mx)
    gl.store(STATS+32*N+row,inv)

@gluon.jit
def _prob(S,offset,mask,mx,inv,SCALE:gl.constexpr):
    raw=gl.load(S+offset,mask,0).to(gl.float32)
    scaled=(raw*SCALE).to(gl.bfloat16).to(gl.float32)
    value=_exp(scaled-mx)*inv
    return gl.where(mask,value,0.0).to(gl.bfloat16)

'''
pv=(repo/'atom/model_ops/mellum_prefill_sparse_pv.py').read_text()
pv=pv[pv.index('@gluon.jit'):pv.index('\ndef pv(')]
pv=pv.replace('def _pv(P,V,O,N,','def _fused_pv(S,V,STATS,O,N,SCALE:gl.constexpr,')
pv=pv.replace('first=gl.maximum(0,(qbase-1023)//DEPTH)','first=0')
anchor='    pk=gl.arange(0,DEPTH,layout=gl.SliceLayout(0,pl))'
assert pv.count(anchor)==1
pv=pv.replace(anchor,'    mx=gl.load(STATS+head*N+rows,rows<N,0)[:,None]\n    inv=gl.load(STATS+32*N+head*N+rows,rows<N,0)[:,None]\n'+anchor)
old='p=gl.load(P+(head.to(gl.int64)*N+rows[:,None])*N+kk+pk[None,:],(rows[:,None]<N)&(kk+pk[None,:]<=rows[:,None])&(kk+pk[None,:]>rows[:,None]-1024),0)'
new='p=_prob(S,(head.to(gl.int64)*N+rows[:,None])*N+kk+pk[None,:],(rows[:,None]<N)&(kk+pk[None,:]<=rows[:,None]),mx,inv,SCALE)'
assert pv.count(old)==1;pv=pv.replace(old,new)
old='p=gl.load(P+(head.to(gl.int64)*N+rows[:,None])*N+kk+pk[None,:],(rows[:,None]<N)&(kk+pk[None,:]<N)&(kk+pk[None,:]<=rows[:,None])&(kk+pk[None,:]>rows[:,None]-1024),0)'
new='p=_prob(S,(head.to(gl.int64)*N+rows[:,None])*N+kk+pk[None,:],(rows[:,None]<N)&(kk+pk[None,:]<N)&(kk+pk[None,:]<=rows[:,None]),mx,inv,SCALE)'
assert pv.count(old)==1;pv=pv.replace(old,new)
wrapper='''
def attention(scores,value,scale,mi=16,kw=8,row_tile=288,depth=64,rotate=False,bm=32):
    n=scores.shape[-1]
    assert scores.shape==(1,32,n,n) and scores.is_contiguous() and scores.dtype==torch.bfloat16
    assert value.shape==(1,32,n,128) and value.is_contiguous() and value.dtype==torch.bfloat16
    stats=torch.empty((2,32*n),device=scores.device,dtype=torch.float32)
    _row_stats[(32*n,)](scores,stats,n,n,n,scale,tr.next_power_of_2(tr.cdiv(n,2048)),n%4==0,num_warps=8,enable_fp_fusion=False)
    out=torch.empty_like(value)
    assert not rotate or row_tile % bm == 0
    _fused_pv[(tr.cdiv(n,bm),32)](scores,value,stats,out,n,scale,mi,kw,row_tile,depth,rotate,bm,128,num_warps=4,enable_fp_fusion=False)
    return out
'''
target=w/'global_softmax_pv_candidate.py'
target.write_text(stats+pv+wrapper)
compile(target.read_text(),str(target),'exec')
print(target)
