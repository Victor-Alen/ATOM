"""Freeze an explicitly selected, fully measured candidate for final evidence."""
from pathlib import Path
import argparse,json,os,subprocess
p=argparse.ArgumentParser();p.add_argument('--label',required=True,choices=['global_qk','triangular_qk']);args=p.parse_args()
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
comparison=json.loads((w/'final_candidate_comparison.json').read_text())
row=next(row for row in comparison['candidates'] if row['label']==args.label)
assert comparison['recommended']==args.label,'Explicit override requires a separate reviewed decision'
full=Path(row['full']);repo=Path(row['repo']);target=w/'frozen_final_candidate_20261106.json'
assert not target.exists() and (full/'DONE').exists()
assert json.loads((full/'correctness/acceptance.json').read_text())['passed']
assert json.loads((full/'additional_long_context/summary.json').read_text())['passed']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==row['source_commit']
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
live=json.loads((Path(latest['run_dir'])/'manifest.json').read_text())
assert live['cwd']==str(repo) and live['optimization_points']==[1,1,1]
selection={key:row[key] for key in ['repo','full','source_commit']}
temporary=target.with_suffix('.tmp');temporary.write_text(json.dumps(selection,indent=2));os.replace(temporary,target)
print(json.dumps(selection,indent=2))
