"""Record the frozen runtime without creating a GPU context."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.metadata,json,platform,shutil,subprocess,sys
import psutil
parser=argparse.ArgumentParser();parser.add_argument('--repo',required=True);parser.add_argument('--out',required=True);args=parser.parse_args()
repo=Path(args.repo)
versions={}
for name in ('torch','transformers','triton','aiter','numpy','aiohttp'):
    try:versions[name]=importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:versions[name]='not registered as a distribution; see bundled source manifest'
bench=subprocess.check_output(['/workspace/bench-venv/bin/python','-c','import importlib.metadata;print(importlib.metadata.version("evalscope"))'],text=True).strip()
tool=shutil.which('rocm-smi') or '/opt/rocm/bin/rocm-smi'
gpu=subprocess.run([tool,'--showbus','--showproductname','--showmeminfo','vram','--json'],capture_output=True,text=True,timeout=30)
assert gpu.returncode==0,gpu.stderr
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
runtime=json.loads((Path(latest['run_dir'])/'manifest.json').read_text())
assert runtime['cwd']==str(repo)
services=[]
for proc in psutil.process_iter():
    try:
        command=proc.cmdline()
        if 'atom.entrypoints.openai_server' not in command:continue
        env=proc.environ();devices=[]
        for child in [proc]+proc.children(recursive=True):
            for path in Path('/proc/'+str(child.pid)+'/fdinfo').glob('*'):
                try:
                    fields=dict(line.split(':',1) for line in path.read_text().splitlines() if line.startswith('drm-'))
                    if 'drm-pdev' in fields:devices.append(dict(pid=child.pid,**{key:value.strip() for key,value in fields.items()}))
                except OSError:pass
        services.append(dict(pid=proc.pid,cwd=proc.cwd(),command=command,hip_device=env.get('HIP_VISIBLE_DEVICES'),rocr_devices=env.get('ROCR_VISIBLE_DEVICES'),drm_fdinfo=devices))
    except (psutil.NoSuchProcess,psutil.AccessDenied):pass
files=['deployment/runtime-manifest.json','deployment/runtime-parts.json','scripts/server_profiles/fast.json']
record=dict(time_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Read-only package/driver/inventory snapshot after measurements; no GPU context created by this collector.',python=sys.version,platform=platform.platform(),versions=versions,evalscope=bench,rocm_smi_stdout=gpu.stdout,rocm_smi_stderr=gpu.stderr,visible_devices={key:runtime['env'][key] for key in ('ROCR_VISIBLE_DEVICES','HIP_VISIBLE_DEVICES')},repo=str(repo),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),files_sha256={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in files},service_manifest=str(Path(latest['run_dir'])/'manifest.json'))
record['services_observed']=services
record['host_idle_scope']='Another independent server uses HIP0 on the same host. This is not a whole-host-idle measurement. Own serving allocations are verified by /proc/PID/fdinfo DRM PCI and VRAM records.'
Path(args.out).write_text(json.dumps(record,indent=2));print(json.dumps({key:record[key] for key in ('versions','evalscope','visible_devices','source_commit')},indent=2))
