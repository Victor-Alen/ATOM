"""Validate and fully measure one committed global-QK candidate."""
from pathlib import Path
import asyncio,datetime,hashlib,json,os,subprocess,sys,time
import aiohttp,psutil
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
while not (w/'GLOBAL_SOFTMAX_PV_RESTORED').exists():time.sleep(10)
control=Path('/workspace/ATOM-csig-global-qk');repo=Path('/workspace/ATOM-csig-triangular-qk')
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
runtime=json.loads((Path(latest['run_dir'])/'manifest.json').read_text())
assert runtime['cwd']==str(control)
assert psutil.Process(latest['pid']).cmdline()==runtime['command']
subprocess.run(['/opt/venv/bin/python3',str(control/'scripts/stop_server.py')],check=True)
for _ in range(60):
    if not psutil.pid_exists(latest['pid']):break
    time.sleep(1)
assert not psutil.pid_exists(latest['pid'])
out=w/('triangular_qk_model_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
status=dict(output=str(out),pid=os.getpid(),stage='correctness')
(w/'latest_triangular_qk_model.json').write_text(json.dumps(status,indent=2))
(out/'source_commit.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True))
def hashes():
    files=list((repo/'atom').rglob('*.py'))+list((repo/'scripts').rglob('*.py'))+list((repo/'scripts/server_profiles').glob('*.json'))
    return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
before=hashes();(out/'source_hashes.json').write_text(json.dumps(before,indent=2))
async def check_a():
    sys.path.insert(0,str(w.parent));import ablate_ops as a
    a.v.OUT=out
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=3600),connector=aiohttp.TCPConnector(force_close=True)) as session:
        result=await a.v.batch(session,'A8_HF64',8000,a.v.read('hf_scenario_a_20_eager.jsonl')[:8],8)
    (out/'A8_correctness.json').write_text(json.dumps(result,indent=2))
    assert result['complete'] and result['matched_positions']==result['total_positions']
try:
    with (out/'startup.log').open('w') as log:subprocess.run(['bash',str(repo/'scripts/start_server.sh')],stdout=log,stderr=subprocess.STDOUT,check=True)
    live=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
    for name in ('manifest.json','smoke.json'):(out/name).write_bytes((Path(live['run_dir'])/name).read_bytes())
    with (out/'additional_long_context.log').open('w') as log:
        subprocess.run(['/opt/venv/bin/python3',str(w/'validate_additional_long_context.py'),'--references',str(w/'additional_long_context_hf_20261106'),'--out',str(out/'additional_long_context')],stdout=log,stderr=subprocess.STDOUT,check=True)
    with (out/'correctness.log').open('w') as log:
        subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/validate_public.py'),'--out',str(out/'correctness')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
    gate=json.loads((out/'correctness/acceptance.json').read_text());assert gate['passed']
    asyncio.run(check_a())
    with (out/'screen.log').open('w') as log:
        subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/benchmark.py'),'--screen','--repeat','1','--out',str(out/'screen')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
    status['stage']='full_performance';(w/'latest_triangular_qk_model.json').write_text(json.dumps(status,indent=2))
    with (out/'performance.log').open('w') as log:
        subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/benchmark.py'),'--repeat','3','--out',str(out/'performance')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
    assert hashes()==before
    with (out/'performance_summary.json').open('w') as summary:
        subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/summarize_benchmark.py'),str(out/'performance')],cwd=repo,stdout=summary,check=True)
    status['stage']='done';(w/'latest_triangular_qk_model.json').write_text(json.dumps(status,indent=2))
    (out/'DONE').write_text('Full correctness and three complete public performance rounds passed. Candidate remains running.\n')
    print('TRIANGULAR_QK_MODEL_FULL_DONE',out,flush=True)
except BaseException:
    status['stage']='failed';(w/'latest_triangular_qk_model.json').write_text(json.dumps(status,indent=2))
    subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/stop_server.py')],check=False)
    with (out/'restore.log').open('w') as log:subprocess.run(['bash',str(control/'scripts/start_server.sh')],stdout=log,stderr=subprocess.STDOUT,check=True)
    raise
