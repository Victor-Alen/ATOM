import json,psutil,subprocess
from pathlib import Path
rows=[]
for proc in psutil.process_iter():
    try:
        cmd=proc.cmdline()
        if 'atom.entrypoints.openai_server' not in cmd:continue
        env=proc.environ();children=[]
        for child in proc.children(recursive=True):
            drm=[]
            for fdinfo in Path('/proc/'+str(child.pid)+'/fdinfo').glob('*'):
                try:
                    lines=[line for line in fdinfo.read_text().splitlines() if line.startswith('drm-')]
                    if lines:drm.append(lines)
                except OSError:pass
            children.append(dict(pid=child.pid,cmd=child.cmdline(),drm=drm,nspid=next((s for s in open('/proc/'+str(child.pid)+'/status') if s.startswith('NSpid:')),None)))
        rows.append(dict(pid=proc.pid,cwd=proc.cwd(),cmd=cmd,devices={k:env.get(k) for k in ['HIP_VISIBLE_DEVICES','ROCR_VISIBLE_DEVICES']},children=children))
    except (psutil.NoSuchProcess,psutil.AccessDenied):pass
print(json.dumps(rows,indent=2))
for row in rows:
    ids=[row['pid']]+[child['pid'] for child in row['children']]
    if '8000' in row['cmd']:subprocess.run(['rocm-smi','--showpidgpus',*[str(pid) for pid in ids],'--json'])
