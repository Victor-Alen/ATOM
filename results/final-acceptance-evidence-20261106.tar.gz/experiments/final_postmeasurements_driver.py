"""Wait for deliberate final-candidate selection, then run required evidence tasks."""
from pathlib import Path
import hashlib,json,os,subprocess,time
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
choice=w/'frozen_final_candidate_20261106.json'
print('WAIT_EXPLICIT_FINAL_CANDIDATE_FILE',flush=True)
while not choice.exists():time.sleep(10)
selected=json.loads(choice.read_text());repo=Path(selected['repo']);full=Path(selected['full'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head==selected['source_commit']
assert (full/'DONE').exists()
assert json.loads((full/'correctness/acceptance.json').read_text())['passed']
audit=json.loads((full/'performance/audited_summary.json').read_text())
assert audit['repeats']==3 and audit['all_requests_successful'] and audit['all_outputs_256']
status=dict(selected,driver_pid=os.getpid(),stage='ablation')
(w/'latest_final_postmeasurements.json').write_text(json.dumps(status,indent=2))
with (w/'final_cumulative_ablation.log').open('w') as log:
    subprocess.run(['/opt/venv/bin/python3',str(w/'run_final_cumulative_ablation.py'),'--repo',str(repo),'--full',str(full)],stdout=log,stderr=subprocess.STDOUT,check=True)
status['stage']='profiling';(w/'latest_final_postmeasurements.json').write_text(json.dumps(status,indent=2))
with (w/'final_delivery_profile.log').open('w') as log:
    subprocess.run(['/opt/venv/bin/python3',str(w/'profile_final_delivery.py'),'--repo',str(repo)],stdout=log,stderr=subprocess.STDOUT,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
status['stage']='done';(w/'latest_final_postmeasurements.json').write_text(json.dumps(status,indent=2))
(w/'FINAL_POSTMEASUREMENTS_DONE').write_text('Complete same-revision four-row ablation, three profiler windows, and restored default service.\n')
print('FINAL_POSTMEASUREMENTS_DONE',flush=True)
