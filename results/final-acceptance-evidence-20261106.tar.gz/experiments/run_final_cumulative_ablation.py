from pathlib import Path
import asyncio,datetime,hashlib,json,os,subprocess,sys,time
import psutil,aiohttp
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--repo',required=True);parser.add_argument('--full',required=True);args=parser.parse_args()
r=Path('/workspace/logs/step0_operator_parallel_20261104');work=r/'startup_delivery';repo=Path(args.repo).resolve();fullpath=Path(args.full).resolve()
assert (fullpath/'DONE').exists()
assert json.loads((fullpath/'correctness/acceptance.json').read_text())['passed']
assert json.loads((fullpath/'performance/audited_summary.json').read_text())['all_requests_successful']
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
manifest=json.loads((Path(latest['run_dir'])/'manifest.json').read_text());assert manifest['cwd']==str(repo)
label='final_cumulative_ablation_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=r/label;out.mkdir();(work/'latest_final_cumulative_ablation.json').write_text(json.dumps(dict(output=str(out),pid=os.getpid())))
(out/'source_commit.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True))
sys.path.insert(0,str(r));import ablate_ops as a
results=[]
def stop():
    subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/stop_server.py')],check=True)
    latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
    for _ in range(30):
        if not psutil.pid_exists(latest['pid']):break
        time.sleep(1)
    assert not psutil.pid_exists(latest['pid'])
async def check(folder):
    a.v.OUT=folder
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=3600),connector=aiohttp.TCPConnector(force_close=True)) as session:
        x=await a.v.batch(session,'A8_HF64',8000,a.v.read('hf_scenario_a_20_eager.jsonl')[:8],8)
        c=a.v.read('hf_scenario_c_200_eager.jsonl')
        y=await a.v.batch(session,'C4_HF64',8000,[c[i] for i in [0,49,100,199]],1)
        ref=json.loads(Path('/workspace/logs/step0_five_gate_20261104/strict_16k_hf.json').read_text())
        async with session.post('http://127.0.0.1:8000/v1/completions',json=dict(model=a.v.MODEL,prompt=ref['prompt'],max_tokens=64,temperature=0.,ignore_eos=True,stream=False)) as response:
            response.raise_for_status();body=await response.json()
        exact=body['token_ids']==ref['token_ids'] and body['usage']['prompt_tokens']==16384
        (folder/'strict16k.json').write_text(json.dumps(dict(exact=exact,response=body)))
        return dict(matched=x['matched_positions']+y['matched_positions']+sum(i==j for i,j in zip(body['token_ids'],ref['token_ids'])),total=832,passed=exact and x['complete'] and y['complete'] and x['matched_positions']==x['total_positions'] and y['matched_positions']==y['total_positions'])
for config in ('step0','point1','point12','point123'):
    folder=out/config;folder.mkdir()
    print('ABLATION_START',config,flush=True);stop()
    with (folder/'startup.log').open('w') as log:
        subprocess.run(['bash',str(repo/'scripts/start_server.sh'),'--ablation',config,'--gpu','1'],stdout=log,stderr=subprocess.STDOUT,check=True)
    latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
    manifest=json.loads((Path(latest['run_dir'])/'manifest.json').read_text());(folder/'runtime.json').write_text(json.dumps(manifest,indent=2))
    gate=asyncio.run(check(folder));(folder/'correctness.json').write_text(json.dumps(gate,indent=2))
    assert gate['passed'],(config,gate)
    benchmark=folder/'performance'
    with (folder/'benchmark.log').open('w') as log:
        subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/benchmark.py'),'--screen','--repeat','1','--out',str(benchmark)],stdout=log,stderr=subprocess.STDOUT,check=True)
    with (folder/'request_audit_summary.json').open('w') as audit:
        subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/summarize_benchmark.py'),str(benchmark),'--expected-repeats','1'],stdout=audit,check=True)
    metrics={}
    for scene in 'ABC':
        p=benchmark/'r0'/scene
        summary=json.loads(next(p.rglob('benchmark_summary.json')).read_text())
        percent=json.loads(next(p.rglob('benchmark_percentile.json')).read_text())
        assert summary['Failed Requests']==0
        metrics[scene]=dict(summary=summary,percentile=percent)
    row=dict(config=config,points=manifest['optimization_points'],gpus=1,correctness=gate,metrics=metrics)
    results.append(row);(out/'results.json').write_text(json.dumps(dict(scope='Controlled screening ablation: A64/B8/C12, one repeat per row. Same prompts/seed/256-token output/arrival protocol. C p99 is a small-sample estimate; full 3x ABC winner results are reported separately.',rows=results,full_winner=str(fullpath)),indent=2))
    print('ABLATION_DONE',config,flush=True)
(out/'DONE').write_text('Four cumulative configurations complete; final default point123 restored.\n')
print('CUMULATIVE_DONE',out,flush=True)
