"""Archive the deliberately selected model, same-version evidence, and late probes."""
from pathlib import Path
import hashlib,json,tarfile,subprocess,sys
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
assert (w/'FINAL_POSTMEASUREMENTS_DONE').exists()
selection=json.loads((w/'frozen_final_candidate_20261106.json').read_text())
subprocess.run([sys.executable,str(w/'collect_final_environment.py'),'--repo',selection['repo'],'--out',str(w/'final_environment.json')],check=True)
full=Path(selection['full'])
ablation=Path(json.loads((w/'latest_final_cumulative_ablation.json').read_text())['output'])
profile=Path(json.loads((w/'latest_final_delivery_profile.json').read_text())['output'])
assert all((folder/'DONE').exists() for folder in (full,ablation,profile))
archive=w/'final-acceptance-evidence-20261106.tar.gz'
assert not archive.exists()
members=[]
def digest(path):
    with path.open('rb') as file:return hashlib.file_digest(file,'sha256').hexdigest()
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    def add(source,name):
        if source.is_dir():
            for child in sorted(source.rglob('*')):
                if child.is_file() and '__pycache__' not in child.parts:add(child,name+'/'+str(child.relative_to(source)))
        else:
            tar.add(source,arcname=name,recursive=False)
            members.append(dict(path=name,size=source.stat().st_size,sha256=digest(source),source=str(source)))
    add(full,'model')
    add(ablation,'ablation')
    add(profile,'profiling')
    add(w/'additional_long_context_hf_20261106','additional-long-context-hf')
    add(Path('/data/datasets/baseline.json'),'baseline.json')
    add(w/'frozen_final_candidate_20261106.json','selection.json')
    add(w/'final_environment.json','environment.json')
    add(w/'collect_final_environment.py','experiments/collect_final_environment.py')
    add(w/'inspect_live_ownership.py','experiments/inspect_live_ownership.py')
    add(w/'freeze_final_choice.py','experiments/freeze_final_choice.py')
    add(w/'live_ownership_20261106T0614.log','experiments/live_ownership_20261106T0614.log')
    for name in ('global_softmax_pv_operator_validation.json','lane_occupancy_operator_validation.json','triangular_qk_operator_validation.json','global_softmax_pv_probe.log','lane_occupancy_probe.log','triangular_qk_probe.log','generate_additional_long_context_hf.py','validate_additional_long_context.py','prepare_global_softmax_pv_probe.py','global_softmax_pv_candidate.py','probe_global_softmax_pv.py','probe_lane_occupancy.py','prepare_triangular_qk_probe.py','triangular_global_qk_candidate.py','probe_triangular_global_qk.py','prepare_triangular_model.py','run_triangular_qk_model.py','run_global_qk_model.py','run_global_softmax_pv_after_full.py','run_final_cumulative_ablation.py','profile_final_delivery.py','final_postmeasurements_driver.py','compare_final_candidates.py','final_candidate_comparison.json','package_final_acceptance.py'):
        add(w/name,'experiments/'+name)
    control=Path(json.loads((w/'latest_global_qk_model.json').read_text())['output'])
    if control!=full:add(control,'global-qk-control')
    triangular=Path(json.loads((w/'latest_triangular_qk_model.json').read_text())['output'])
    if triangular!=full:add(triangular,'triangular-qk-candidate')
manifest=dict(archive=str(archive),size=archive.stat().st_size,sha256=digest(archive),selection=selection,source_roots=dict(model=str(full),ablation=str(ablation),profiling=str(profile)),members=members)
(w/'final-acceptance-evidence-20261106.manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({k:v for k,v in manifest.items() if k!='members'},indent=2));print('MEMBERS',len(members))
