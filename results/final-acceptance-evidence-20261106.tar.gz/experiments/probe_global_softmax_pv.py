"""Fixed-input exactness and latency; never treated as end-to-end performance."""
from pathlib import Path
import gc,json,os,statistics
import torch
from atom.model_ops.mellum_prefill_softmax_hybrid import softmax
import global_softmax_pv_candidate as candidate
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
import subprocess,sys
# The model benchmark is already finished and its service stopped by the driver.
# Build additional HF correctness references before any operator timing begins.
with (w/'additional_long_context_hf.log').open('w') as log:
    fresh_code=subprocess.run([sys.executable,str(w/'generate_additional_long_context_hf.py')],cwd=w,stdout=log,stderr=subprocess.STDOUT).returncode
print('ADDITIONAL_HF_REFERENCE_EXIT',fresh_code,flush=True)
profiles=json.loads(Path(os.environ['ATOM_MELLUM_PREFILL_PV_CONFIG']).read_text())['profiles']
torch.manual_seed(20261106);results=[]
def measure(fn):
    for _ in range(3):y=fn()
    torch.cuda.synchronize();times=[]
    for _ in range(7):
        a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
        a.record();y=fn();b.record();b.synchronize();times.append(a.elapsed_time(b))
    return statistics.median(times)
for n in (4096,4097,6143,8192,8193,12001,15965,16384):
    if str(n) not in profiles:
        print('UNSUPPORTED_PROFILE',n,flush=True);continue
    s=torch.randn((1,32,n,n),device='cuda',dtype=torch.bfloat16)*8
    v=torch.randn((1,32,n,128),device='cuda',dtype=torch.bfloat16)
    def reference():return torch.matmul(softmax(s,n,n,None,128**-.5),v)
    ref=reference();row=dict(n=n,profile=profiles[str(n)],reference_ms=measure(reference),candidates=[])
    for bm in (32,64,128):
        if profiles[str(n)].get('rotate') and profiles[str(n)]['row_tile']%bm:
            row['candidates'].append(dict(bm=bm,skipped='Would cross rotation row boundary'));continue
        def operation():return candidate.attention(s,v,128**-.5,**profiles[str(n)],bm=bm)
        entry=dict(bm=bm)
        try:
            got=operation();torch.cuda.synchronize()
            entry['different']=int((got!=ref).sum().item());entry['max_abs']=float((got.float()-ref.float()).abs().max())
            entry['total_values']=got.numel();entry['different_fraction']=entry['different']/got.numel()
            entry['finite']=bool(torch.isfinite(got).all())
            if entry['finite']:entry['ms']=measure(operation)
            del got
        except Exception as e:entry['error']=repr(e)
        row['candidates'].append(entry)
    valid=[entry for entry in row['candidates'] if entry.get('different')==0]
    measured=[entry for entry in row['candidates'] if 'ms' in entry]
    if measured:row['fastest_measured_regardless_of_accuracy']=min(measured,key=lambda entry:entry['ms'])
    if valid:row['best_exact']=min(valid,key=lambda entry:entry['ms'])
    if measured and n in (8193,16384):
        chosen=row.get('best_exact',row['fastest_measured_regardless_of_accuracy'])
        row['repeat40_candidate']=dict(bm=chosen['bm'],exact=chosen['different']==0)
        row['repeat40_different']=[int((candidate.attention(s,v,128**-.5,**profiles[str(n)],bm=chosen['bm'])!=ref).sum().item()) for _ in range(40)]
    results.append(row);print(json.dumps(row),flush=True)
    (w/'global_softmax_pv_operator_validation.json').write_text(json.dumps(dict(scope='FIXED_INPUT_OPERATOR_ONLY',results=results),indent=2))
    del s,v,ref;gc.collect();torch.cuda.empty_cache()
print('SOFTMAX_PV_PROBE_DONE',flush=True)
# A distinct, sequential experiment reuses the already exclusive GPU window.
# Its results do not alter the fusion measurements above or any live model.
import subprocess,sys
with (w/'lane_occupancy_probe.log').open('w') as log:
    subprocess.run([sys.executable,str(w/'probe_lane_occupancy.py')],cwd=w,stdout=log,stderr=subprocess.STDOUT,check=True)
with (w/'triangular_qk_probe.log').open('w') as log:
    subprocess.run([sys.executable,str(w/'probe_triangular_global_qk.py')],cwd=w,stdout=log,stderr=subprocess.STDOUT,check=True)
