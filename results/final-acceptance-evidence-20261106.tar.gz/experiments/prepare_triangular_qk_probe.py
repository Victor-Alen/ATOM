"""Eliminate empty future-tile workgroups; arithmetic and BF16 stores stay identical."""
from pathlib import Path
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
source=Path('/workspace/ATOM-csig-global-qk/atom/model_ops/mellum_prefill_global_qk.py').read_text()
source=source.replace('BM:gl.constexpr,BN:gl.constexpr):','BM:gl.constexpr,BN:gl.constexpr,TRI:gl.constexpr):')
old='    if ORDER == 0:\n        qb=gl.program_id(0);kb=gl.program_id(1);head=gl.program_id(2)'
new='''    if TRI:
        head=gl.program_id(0)
        item=gl.program_id(1)
        pair=item // (BN//BM)
        qsub=item % (BN//BM)
        group=((gl.sqrt(pair.to(gl.float32)*8.0+1.0)-1.0)*0.5).to(gl.int32)
        base=group*(group+1)//2
        group=group+(base+group+1<=pair).to(gl.int32)
        base=group*(group+1)//2
        group=group-(base>pair).to(gl.int32)
        kb=pair-group*(group+1)//2
        qb=group*(BN//BM)+qsub
    elif ORDER == 0:
        qb=gl.program_id(0);kb=gl.program_id(1);head=gl.program_id(2)'''
assert source.count(old)==1;source=source.replace(old,new)
source=source.replace('order=1,depth=32,bm=64):','order=1,depth=32,bm=64,triangular=True):')
anchor='    _qk[grid](q,k,out,n,q.stride(0),q.stride(1),k.stride(0),k.stride(1),n,mi,kw,split,row_tile,depth,order,bm,bn,num_warps=4,enable_fp_fusion=False)'
replacement='''    triangular=bool(triangular and row_tile%bm==0 and bn%bm==0)
    if triangular:
        groups=tr.cdiv(n,bn)
        grid=(32,groups*(groups+1)//2*(bn//bm))
    _qk[grid](q,k,out,n,q.stride(0),q.stride(1),k.stride(0),k.stride(1),n,mi,kw,split,row_tile,depth,order,bm,bn,triangular,num_warps=4,enable_fp_fusion=False)'''
assert source.count(anchor)==1;source=source.replace(anchor,replacement)
target=w/'triangular_global_qk_candidate.py';target.write_text(source);compile(source,str(target),'exec');print(target)
