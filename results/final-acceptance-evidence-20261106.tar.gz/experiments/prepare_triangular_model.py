"""Isolate only the measured triangular global-QK task mapping."""
from pathlib import Path
import hashlib,json,subprocess
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
control=Path('/workspace/ATOM-csig-global-qk');repo=Path('/workspace/ATOM-csig-triangular-qk')
assert (w/'GLOBAL_SOFTMAX_PV_RESTORED').read_text().strip()=='0'
assert not repo.exists()
subprocess.run(['git','worktree','add','-b','codex/csig-triangular-qk',str(repo),'HEAD'],cwd=control,check=True)
(repo/'.runtime').symlink_to('/workspace/ATOM-csig-final/.runtime',target_is_directory=True)
name='atom/model_ops/mellum_prefill_global_qk.py'
(repo/name).write_bytes((w/'triangular_global_qk_candidate.py').read_bytes())
assert 'def try_qk' in (repo/name).read_text()
profile=repo/'scripts/server_profiles/fast.json';p=json.loads(profile.read_text())
p['source_hashes'][name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
p['evidence']['scope']='Isolated triangular global-QK workgroup mapping; fixed-input operator exact, full-model validation pending. MTP off.'
profile.write_text(json.dumps(p,indent=2)+'\n')
subprocess.run(['git','add',name,'scripts/server_profiles/fast.json'],cwd=repo,check=True)
subprocess.run(['git','commit','-m','Schedule only causal global QK workgroups without changing arithmetic'],cwd=repo,check=True)
subprocess.run(['/opt/venv/bin/python3','-m','py_compile',str(repo/name)],check=True)
with (w/'triangular_qk_model_dry_run.json').open('w') as out:subprocess.run(['bash','scripts/start_server.sh','--dry-run'],cwd=repo,stdout=out,check=True)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True))
