"""Independent original-prefill ablations by architecture layer type."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
import psutil
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
while not (w/'NATIVE_PREFILL_RESTORED').exists():time.sleep(10)
control=Path('/workspace/ATOM-csig-lane-cache');repo=Path('/workspace/ATOM-csig-native-prefill-check')
target=repo/'atom/model_ops/attention_mha.py';source=target.read_text()
old='''        if (__import__('os').environ.get('ATOM_MELLUM_BF16_HF_ATTENTION')=='1'
                and __import__('os').environ.get('ATOM_MELLUM_NATIVE_ATTN_PHASE', '')
                    != ('prefill' if ctx.is_prefill else 'decode')
'''
new='''        native_phase = __import__('os').environ.get('ATOM_MELLUM_NATIVE_ATTN_PHASE', '')
        native_prefill = ctx.is_prefill and (
            native_phase == 'prefill'
            or (native_phase == 'prefill_global' and self.sliding_window <= 0)
            or (native_phase == 'prefill_sliding' and self.sliding_window > 0))
        if (__import__('os').environ.get('ATOM_MELLUM_BF16_HF_ATTENTION')=='1'
                and not native_prefill
                and (ctx.is_prefill or native_phase != 'decode')
'''
assert source.count(old)==1;target.write_text(source.replace(old,new))
root=w/('scoped_native_prefill_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));root.mkdir()
(w/'latest_scoped_native_prefill.json').write_text(json.dumps(dict(output=str(root),pid=os.getpid(),stage='running')))
results=[]
for scope in ('global','sliding'):
    out=root/scope;out.mkdir()
    profile=repo/'scripts/server_profiles/fast.json';p=json.loads(profile.read_text())
    p['env']['ATOM_MELLUM_NATIVE_ATTN_PHASE']='prefill_'+scope
    p['source_hashes'][str(target.relative_to(repo))]=hashlib.sha256(target.read_bytes()).hexdigest()
    p['evidence']['scope']='Isolated original AITER prefill on '+scope+' layers; all other operators fixed. MTP off. Validation pending.'
    profile.write_text(json.dumps(p,indent=2)+'\n')
    subprocess.run(['git','add',str(target.relative_to(repo)),'scripts/server_profiles/fast.json'],cwd=repo,check=True)
    subprocess.run(['git','commit','-m','Validate original fused prefill on '+scope+' attention layers only'],cwd=repo,check=True)
    (out/'source_commit.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True))
    latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
    manifest=json.loads((Path(latest['run_dir'])/'manifest.json').read_text());assert manifest['cwd']==str(control)
    proc=psutil.Process(latest['pid']);assert proc.cmdline()==manifest['command']
    subprocess.run(['/opt/venv/bin/python3',str(control/'scripts/stop_server.py')],check=True)
    for _ in range(60):
        if not psutil.pid_exists(latest['pid']):break
        time.sleep(1)
    assert not psutil.pid_exists(latest['pid'])
    try:
        with (out/'startup.log').open('w') as log:subprocess.run(['bash',str(repo/'scripts/start_server.sh')],stdout=log,stderr=subprocess.STDOUT,check=True)
        live=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
        for name in ('manifest.json','smoke.json'):(out/name).write_bytes((Path(live['run_dir'])/name).read_bytes())
        with (out/'correctness.log').open('w') as log:
            code=subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/validate_public.py'),'--out',str(out/'correctness')],cwd=repo,stdout=log,stderr=subprocess.STDOUT).returncode
        acceptance=json.loads((out/'correctness/acceptance.json').read_text());strict=json.loads((out/'correctness/strict_16k.json').read_text())
        ratio=strict['matched']/strict['total']
        passed=(acceptance['C']['complete'] and acceptance['C']['agreement']>=.9 and strict['complete'] and strict['input_tokens']==16384 and ratio>=.9 and abs(acceptance['HumanEval']['gap_pp'])<=2)
        review=dict(scope=scope,source_commit=(out/'source_commit.txt').read_text().strip(),full_public_correctness=acceptance,strict16k_agreement=ratio,assignment_gate_with_16k_90pct=passed,original_strict_client_exit=code,MTP=False,num_gpus=1)
        (out/'review.json').write_text(json.dumps(review,indent=2));results.append(review)
        if passed:
            with (out/'performance.log').open('w') as log:subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/benchmark.py'),'--screen','--repeat','1','--out',str(out/'performance')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
        (out/'DONE').write_text('completed\n');print(json.dumps(review,indent=2),flush=True)
    finally:
        subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/stop_server.py')],check=False)
        with (out/'restore.log').open('w') as log:subprocess.run(['bash',str(control/'scripts/start_server.sh')],stdout=log,stderr=subprocess.STDOUT,check=True)
    (root/'results.json').write_text(json.dumps(results,indent=2))
(root/'DONE').write_text('completed\n');(w/'SCOPED_PREFILL_RESTORED').write_text('complete')
(w/'latest_scoped_native_prefill.json').write_text(json.dumps(dict(output=str(root),pid=os.getpid(),stage='done')))
