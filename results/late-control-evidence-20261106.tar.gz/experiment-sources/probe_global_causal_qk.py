"""Compare global causal tiles with the frozen HF-shaped BF16 QK GEMM."""
from pathlib import Path
import gc,json,os,statistics,time
import torch
import mellum_global_causal_qk_candidate as candidate

w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
profiles=json.loads(Path(os.environ['ATOM_MELLUM_PREFILL_QK_CONFIG']).read_text())['profiles']
torch.manual_seed(20261106)
results=[]
def measure(fn):
    for _ in range(3):y=fn()
    torch.cuda.synchronize();times=[]
    for _ in range(7):
        a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
        a.record();y=fn();b.record();b.synchronize();times.append(a.elapsed_time(b))
    del y
    return statistics.median(times)
def differences(a,b,n):
    count=0
    cols=torch.arange(n,device='cuda')[None,:]
    for start in range(0,n,256):
        stop=min(n,start+256);mask=cols<=torch.arange(start,stop,device='cuda')[:,None]
        count+=int(((a[0,:,start:stop]!=b[0,:,start:stop])&mask).sum().item())
    return count

for n in (512,990,1024,1025,2048,2049,3073,4095,4096,4097,6143,7169,8192,8193,12001,15965,16384):
    if str(n) not in profiles:
        print('UNSUPPORTED_PROFILE',n,flush=True)
        continue
    q=torch.randn((n,32,128),device='cuda',dtype=torch.bfloat16)
    k=torch.randn((n,4,128),device='cuda',dtype=torch.bfloat16)
    query=q.transpose(0,1).unsqueeze(0)
    key=k.transpose(0,1).unsqueeze(0)[:,:,None,:,:].expand(1,4,8,n,128).reshape(1,32,n,128)
    def reference():return torch.matmul(query,key.transpose(2,3))
    ref=reference();base=measure(reference)
    profile=profiles[str(n)]
    if isinstance(profile,int):profile={'row_tile':profile}
    row=dict(n=n,profile=profile,reference_ms=base,candidates=[])
    for bm,bn in ((32,64),(32,128),(64,128),(64,256),(128,128)):
        params=dict(profile,bm=bm,bn=bn)
        try:
            def operation():return candidate.qk(q,k,**params)
            got=operation();torch.cuda.synchronize();diff=differences(got,ref,n)
            entry=dict(bm=bm,bn=bn,different=diff)
            if diff==0:entry['ms']=measure(operation)
            row['candidates'].append(entry);del got
        except Exception as exc:
            row['candidates'].append(dict(bm=bm,bn=bn,error=repr(exc)))
        print(json.dumps(dict(n=n,result=row['candidates'][-1])),flush=True)
    valid=[r for r in row['candidates'] if r.get('different')==0]
    if valid:
        best=min(valid,key=lambda r:r['ms']);row['best']=best
        if n in (8193,16384):
            params=dict(profile,bm=best['bm'],bn=best['bn']);repeats=[]
            for i in range(40):
                got=candidate.qk(q,k,**params);repeats.append(differences(got,ref,n));del got
            row['repeat40_different']=repeats
    results.append(row)
    (w/'global_qk_operator_validation.json').write_text(json.dumps(dict(scope='FIXED_INPUT_OPERATOR_ONLY',causal_positions_only=True,results=results),indent=2))
    del q,k,query,key,ref;gc.collect();torch.cuda.empty_cache()
print('GLOBAL_QK_PROBE_DONE',flush=True)
