"""Prepare a separate global-causal QK experiment; never alter the live model."""
from pathlib import Path
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
repo=Path('/workspace/ATOM-csig-final')
source=(repo/'atom/model_ops/mellum_prefill_sparse_qk.py').read_text()
source=source.replace('qbase=qb*BM','qbase=(qb // gl.cdiv(ROW_TILE, BM)) * ROW_TILE + (qb % gl.cdiv(ROW_TILE, BM)) * BM\n    qend=gl.minimum(N,(qbase//ROW_TILE+1)*ROW_TILE)')
source=source.replace('qr[:,None]<N,0','qr[:,None]<qend,0').replace('(rows[:,None]<N)&','(rows[:,None]<qend)&')
source=source[:source.index('\ndef qk(')]
source+='''
def qk(q,k,mi=16,kw=4,split=False,row_tile=160,bn=128,order=1,depth=32,bm=64):
    n=q.shape[0];assert q.shape==(n,32,128) and k.shape==(n,4,128)
    assert q.dtype==k.dtype==torch.bfloat16 and q.stride(-1)==k.stride(-1)==1
    out=torch.empty((1,32,n,n),device=q.device,dtype=q.dtype)
    qtiles=tr.cdiv(n,row_tile)*tr.cdiv(row_tile,bm)
    ktiles=tr.cdiv(n,bn)
    grid=[(qtiles,ktiles,32),(32,ktiles,qtiles),(ktiles,32,qtiles)][order]
    _qk[grid](q,k,out,n,q.stride(0),q.stride(1),k.stride(0),k.stride(1),n,mi,kw,split,row_tile,depth,order,bm,bn,num_warps=4,enable_fp_fusion=False)
    return out
'''
(w/'mellum_global_causal_qk_candidate.py').write_text(source)
print(w/'mellum_global_causal_qk_candidate.py')
