"""Commit the validated softmax control and isolate global causal QK."""
from pathlib import Path
import hashlib,json,subprocess
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
control=Path('/workspace/ATOM-csig-lane-cache')
repo=Path('/workspace/ATOM-csig-global-qk')
assert not repo.exists()
full=Path(json.loads((w/'latest_lane_model_full.json').read_text())['output'])
assert (full/'DONE').exists()
record=json.loads((full/'final_summary.json').read_text())
assert record['correctness']['passed'] and record['source_unchanged']
files=['atom/model_ops/mellum_prefill_softmax_hybrid.py','atom/model_ops/mellum_prefill_softmax_lane_cache.py','scripts/server_profiles/fast.json']
hashes=json.loads((full/'source_hashes.json').read_text())
for name in files:
    assert hashlib.sha256((control/name).read_bytes()).hexdigest()==hashes[name]
subprocess.run(['git','add',*files],cwd=control,check=True)
subprocess.run(['git','commit','-m','Cache full-attention softmax lanes with exact reduction order and guarded vector stores'],cwd=control,check=True)
subprocess.run(['git','fetch',str(w/'csig-materials.bundle'),'codex/csig-final-20261106'],cwd=control,check=True)
subprocess.run(['git','merge','--no-edit','FETCH_HEAD'],cwd=control,check=True)
subprocess.run(['git','worktree','add','-b','codex/csig-global-qk',str(repo),'HEAD'],cwd=control,check=True)
(repo/'.runtime').symlink_to('/workspace/ATOM-csig-final/.runtime',target_is_directory=True)
kernel=(w/'mellum_global_causal_qk_candidate.py').read_text()
kernel=kernel.replace('this is an isolated screening operator.','the caller must retain that masked-load contract.')
kernel+='''

def try_qk(q, k):
    # Reuse the frozen HF GEMM arithmetic profile. Unsupported shapes fall back.
    from atom.model_ops.mellum_prefill_sparse_qk import _profiles
    n = q.shape[0]
    profile = _profiles().get(n)
    if profile is None or q.shape != (n, 32, 128) or k.shape != (n, 4, 128):
        return None
    if q.dtype != torch.bfloat16 or k.dtype != torch.bfloat16 or q.device != k.device:
        return None
    if q.stride(-1) != 1 or k.stride(-1) != 1:
        return None
    if n > 4096 and (q.stride(0) != 4096 or q.stride(1) != 128):
        return None
    # General length bands control occupancy; no prompt contents are consulted.
    if n <= 4096:
        bm, bn = 32, 64
    elif n <= 8192:
        bm, bn = 128, 128
    elif n <= 12288:
        bm, bn = 64, 256
    else:
        bm, bn = 32, 128
    return qk(q, k, **dict(profile, bm=bm, bn=bn))
'''
(repo/'atom/model_ops/mellum_prefill_global_qk.py').write_text(kernel)
attn=repo/'atom/model_ops/mellum_bf16_attention.py';text=attn.read_text()
anchor='        query = q[start:stop].transpose(0,1).unsqueeze(0)'
addition='''        if (count == context_length and (window is None or window <= 0)
                and 2048 <= key_length <= 16384
                and __import__('os').environ.get('ATOM_MELLUM_PREFILL_GLOBAL_QK') == '1'
                and __import__('os').environ.get('ATOM_MELLUM_FUSED_PREFILL_SOFTMAX') == '1'
                and __import__('os').environ.get('ATOM_MELLUM_PREFILL_SOFTMAX_VARIANT') == 'hybrid'):
            # Only causal positions are written. The hybrid softmax must mask loads.
            from atom.model_ops.mellum_prefill_global_qk import try_qk
            scores = try_qk(q[start:stop], key)
'''
assert text.count(anchor)==1;attn.write_text(text.replace(anchor,addition+anchor))
start=repo/'scripts/start_server.py';text=start.read_text()
anchor='"ATOM_MELLUM_PREFILL_SPARSE_WINDOW"),'
assert text.count(anchor)==1
start.write_text(text.replace(anchor,'"ATOM_MELLUM_PREFILL_SPARSE_WINDOW","ATOM_MELLUM_PREFILL_LANE_CACHE","ATOM_MELLUM_PREFILL_GLOBAL_QK","ATOM_MELLUM_NATIVE_ATTN_PHASE"),'))
profile=repo/'scripts/server_profiles/fast.json';p=json.loads(profile.read_text())
p['env']['ATOM_MELLUM_PREFILL_GLOBAL_QK']='1'
p['evidence']['scope']='Lane softmax full-validated control plus isolated causal global QK; model validation pending. MTP off.'
changed=['atom/model_ops/mellum_prefill_global_qk.py','atom/model_ops/mellum_bf16_attention.py','scripts/start_server.py']
for name in changed:p['source_hashes'][name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
profile.write_text(json.dumps(p,indent=2)+'\n')
subprocess.run(['git','add',*changed,'scripts/server_profiles/fast.json'],cwd=repo,check=True)
subprocess.run(['git','commit','-m','Skip masked global prefill QK tiles while retaining HF BF16 accumulation order'],cwd=repo,check=True)
subprocess.run(['/opt/venv/bin/python3','-m','compileall','-q',*changed],cwd=repo,check=True)
with (w/'global_qk_model_dry_run.json').open('w') as out:
    subprocess.run(['bash','scripts/start_server.sh','--dry-run'],cwd=repo,stdout=out,check=True)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True))
