"""Isolate original AITER fused prefill after the current operator probe completes."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
import psutil
w=Path('/workspace/logs/step0_operator_parallel_20261104/startup_delivery')
while not (w/'GLOBAL_QK_RESTORED').exists():time.sleep(10)
stable=Path('/workspace/ATOM-csig-final');control=Path('/workspace/ATOM-csig-lane-cache');repo=Path('/workspace/ATOM-csig-native-prefill-check')
assert not repo.exists()
subprocess.run(['git','worktree','add','-b','codex/csig-native-prefill-check',str(repo),'2acf18856bd5bd7f4ba22a600eb3d84a9fb4710c'],cwd=stable,check=True)
(repo/'.runtime').symlink_to(stable/'.runtime',target_is_directory=True)
profile=repo/'scripts/server_profiles/fast.json';p=json.loads(profile.read_text())
p['env']['ATOM_MELLUM_NATIVE_ATTN_PHASE']='prefill'
p['env']['ATOM_MELLUM_HF_ATTN_PREFILL_ROUNDING']='0'
p['evidence']['scope']='Isolated original AITER fused prefill ablation. Decode, norm, linear, MoE, graph unchanged. MTP off. Not accepted until full checks.'
profile.write_text(json.dumps(p,indent=2)+'\n')
subprocess.run(['git','add','scripts/server_profiles/fast.json'],cwd=repo,check=True)
subprocess.run(['git','commit','-m','Experiment with original AITER fused prefill after repaired surrounding operators'],cwd=repo,check=True)
latest=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
manifest=json.loads((Path(latest['run_dir'])/'manifest.json').read_text());assert manifest['cwd']==str(control)
proc=psutil.Process(latest['pid']);assert proc.cmdline()==manifest['command']
subprocess.run(['/opt/venv/bin/python3',str(control/'scripts/stop_server.py')],check=True)
for _ in range(60):
    if not psutil.pid_exists(latest['pid']):break
    time.sleep(1)
assert not psutil.pid_exists(latest['pid'])
out=w/('native_prefill_check_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
(w/'latest_native_prefill_check.json').write_text(json.dumps(dict(output=str(out),pid=os.getpid())))
(out/'source_commit.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True))
try:
    with (out/'startup.log').open('w') as log:subprocess.run(['bash',str(repo/'scripts/start_server.sh')],stdout=log,stderr=subprocess.STDOUT,check=True)
    live=json.loads(Path('/workspace/logs/mellum-start-server/latest-8000.json').read_text())
    for name in ('manifest.json','smoke.json'):
        (out/name).write_bytes((Path(live['run_dir'])/name).read_bytes())
    with (out/'correctness.log').open('w') as log:
        code=subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/validate_public.py'),'--out',str(out/'correctness')],cwd=repo,stdout=log,stderr=subprocess.STDOUT).returncode
    acceptance=json.loads((out/'correctness/acceptance.json').read_text())
    strict=json.loads((out/'correctness/strict_16k.json').read_text())
    strict_ratio=strict['matched']/strict['total']
    # The assignment asks for >=90% public token agreement and separate 16k
    # accounting, not non-MTP bitwise equivalence. Apply >=90% to 16k as well.
    passed=(acceptance['C']['complete'] and acceptance['C']['agreement']>=.9 and strict['complete'] and strict['input_tokens']==16384 and strict_ratio>=.9 and abs(acceptance['HumanEval']['gap_pp'])<=2)
    review=dict(scope='FULL_PUBLIC_NATIVE_PREFILL_ABLATION',original_strict_client_exit=code,original_acceptance=acceptance,strict16k_agreement=strict_ratio,assignment_gate_with_16k_90pct=passed,MTP=False,num_gpus=1,
        interpretation='Non-MTP assignment >=90% token agreement; also require complete 16k output and >=90% agreement for that independent case. No precision threshold relaxed below the assignment.')
    (out/'review.json').write_text(json.dumps(review,indent=2))
    if passed:
        with (out/'performance.log').open('w') as log:subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/benchmark.py'),'--screen','--repeat','1','--out',str(out/'performance')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
    (out/'DONE').write_text('Full correctness reviewed; screening performance only if gate passed.\n')
    print(json.dumps(review,indent=2),flush=True)
finally:
    subprocess.run(['/opt/venv/bin/python3',str(repo/'scripts/stop_server.py')],check=False)
    with (out/'restore.log').open('w') as log:subprocess.run(['bash',str(control/'scripts/start_server.sh')],stdout=log,stderr=subprocess.STDOUT,check=True)
(w/'NATIVE_PREFILL_RESTORED').write_text('complete')
