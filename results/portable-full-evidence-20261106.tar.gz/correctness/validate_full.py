"""Production endpoint gates; performance remains in the independent ABC runner."""
import argparse
import asyncio
import json
import shutil
import time
from pathlib import Path
import aiohttp
import ablate_ops as a

async def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--label',required=True)
    parser.add_argument('--port',type=int,default=8024)
    parser.add_argument('--concurrency',type=int,default=8)
    parser.add_argument('--operator-only',action='store_true')
    args=parser.parse_args()
    dest=a.ROOT/'gates'/args.label; dest.mkdir(parents=True,exist_ok=True)
    a.v.OUT=dest
    prior=Path('/workspace/logs/step0_five_gate_20261104')
    common=a.module('gate_common',str(prior/'five_gate_common.py'))
    common.ROOT=dest
    shutil.copy2(prior/'he_worker.py',dest/'he_worker.py')
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=7200), connector=aiohttp.TCPConnector(force_close=True)) as session:
        async def call(prompt,n,ignore=True):
            start=time.monotonic()
            async with session.post(f'http://127.0.0.1:{args.port}/v1/completions',json=dict(model=a.v.MODEL,prompt=prompt,max_tokens=n,temperature=0.0,ignore_eos=ignore,stream=False)) as response:
                response.raise_for_status(); body=await response.json()
            return body,time.monotonic()-start
        strict=json.loads((prior/'strict_16k_hf.json').read_text())
        body,seconds=await call(strict['prompt'],64)
        ids=body['token_ids']
        assert body['usage']['prompt_tokens']==16384 and len(ids)==64
        result=dict(input_tokens=16384,matched_positions=sum(x==y for x,y in zip(ids,strict['token_ids'])),total_positions=64,exact=ids==strict['token_ids'],seconds=seconds,response=body)
        (dest/'strict_16k.json').write_text(json.dumps(result,indent=2)); print('STRICT16K',result['matched_positions'],flush=True)
        c_result=await a.v.batch(session,'C200',args.port,a.v.read('hf_scenario_c_200_eager.jsonl'),args.concurrency)
        if args.operator_only:
            assert result['exact'], 'Strict16k mismatch'
            assert c_result['complete'] and c_result['matched_positions']==c_result['total_positions'], 'C200 mismatch'
            (dest/'OPERATOR_GATE_DONE').write_text('Strict16k and C200 exact. Inspect HumanEval separately for full Step0.\n')
            if args.label in {'native_moe_slot_output_gates', 'native_prefill_down_n128_gates'}:
                import subprocess
                print('FULL_A512_START', args.label, flush=True)
                subprocess.run(['python3', str(a.ROOT/'evalscope_scenarios.py'),
                                '--label', args.label+'_full_a512', '--scenarios', 'A',
                                '--counts', 'A=512,B=50,C=200', '--repeat', '1'], check=True)
            if args.label not in {'native_prefill_rotv1m32_gates', 'native_prefill_down_n128_gates'}:
                return
            print('FULL_HUMANEVAL_START', args.label, flush=True)
        from transformers import AutoTokenizer
        tok=AutoTokenizer.from_pretrained(a.v.MODEL)
        tasks=[json.loads(l) for l in Path('/data/datasets/HumanEval.jsonl').read_text().splitlines()]
        inputs=[json.loads(l) for l in (prior/'he_inputs.jsonl').read_text().splitlines()]
        completed=set()
        if (dest/'he_atom.jsonl').exists(): completed={json.loads(l)['task_id'] for l in (dest/'he_atom.jsonl').read_text().splitlines()}
        semaphore=asyncio.Semaphore(args.concurrency)
        async def he(i):
            if tasks[i]['task_id'] in completed:return
            async with semaphore:
                body,seconds=await call(inputs[i]['prompt'],common.MAX_TOKENS,False)
                assert body['usage']['prompt_tokens']==len(inputs[i]['prompt_token_ids'])
                ids=body['token_ids']
                common.record_he('atom',tasks[i],inputs[i],ids,tok.decode(ids,skip_special_tokens=True),seconds)
        await asyncio.gather(*(he(i) for i in range(164)))
        common.he_summary('atom')
        shutil.copy2(prior/'he_hf_summary.json',dest/'he_hf_summary.json')
        (dest/'DONE').write_text('Validation finished; inspect scores before claiming Step0 pass.\n')

if __name__=='__main__':asyncio.run(main())
